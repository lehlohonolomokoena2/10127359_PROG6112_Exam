/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.mattresssales;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lehlohonolo.Mokoena
 */
public class IProductTest {
    
    public IProductTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of calculateTotalSales method, of class IProduct.
     */
    @Test
    public void testCalculateTotalSales() {
        System.out.println("calculateTotalSales");
        IProduct instance = new IProductImpl();
        int expResult = 0;
        int result = instance.calculateTotalSales();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateAverageSales method, of class IProduct.
     */
    @Test
    public void testCalculateAverageSales() {
        System.out.println("calculateAverageSales");
        IProduct instance = new IProductImpl();
        double expResult = 0.0;
        double result = instance.calculateAverageSales();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getProductName method, of class IProduct.
     */
    @Test
    public void testGetProductName() {
        System.out.println("getProductName");
        IProduct instance = new IProductImpl();
        String expResult = "";
        String result = instance.getProductName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMonthlySales method, of class IProduct.
     */
    @Test
    public void testGetMonthlySales() {
        System.out.println("getMonthlySales");
        IProduct instance = new IProductImpl();
        int[] expResult = null;
        int[] result = instance.getMonthlySales();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IProductImpl implements IProduct {

        public int calculateTotalSales() {
            return 0;
        }

        public double calculateAverageSales() {
            return 0.0;
        }

        public String getProductName() {
            return "";
        }

        public int[] getMonthlySales() {
            return null;
        }
    }
    
}
