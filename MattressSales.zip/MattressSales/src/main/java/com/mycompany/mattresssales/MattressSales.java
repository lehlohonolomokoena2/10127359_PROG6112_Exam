/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattresssales;
import java.util.Scanner;
/**
 *
 * @author Lehlohonolo.Mokoena
 */

// Interface containing the required product methods
interface IProduct {

    int calculateTotalSales();

    double calculateAverageSales();

    String getProductName();

    int[] getMonthlySales();
}


// Product class implementing the IProduct interface
class Product implements IProduct {

    private String productName;
    private int[] monthlySales;

    // Constructor
    public Product(String productName, int[] monthlySales) {
        this.productName = productName;
        this.monthlySales = monthlySales;
    }

    // Return the product name
    @Override
    public String getProductName() {
        return productName;
    }

    // Return the monthly sales
    @Override
    public int[] getMonthlySales() {
        return monthlySales;
    }

    // Calculate the total sales for one product
    @Override
    public int calculateTotalSales() {

        int totalSales = 0;

        for (int sales : monthlySales) {
            totalSales += sales;
        }

        return totalSales;
    }

    // Calculate the average monthly sales for one product
    @Override
    public double calculateAverageSales() {

        if (monthlySales.length == 0) {
            return 0;
        }

        return (double) calculateTotalSales() / monthlySales.length;
    }
}


// Class responsible for printing the sales report
class PrintProduct {

    private String[] monthNames;

    // Constructor
    public PrintProduct(String[] monthNames) {
        this.monthNames = monthNames;
    }

    // Print the complete mattress sales report
    public void printSalesReport(Product[] products) {

        System.out.println();
        System.out.println("==============================================================");
        System.out.println("             MATRESS SALES REPORT");
        System.out.println("               THREE-MONTH SALES REPORT");
        System.out.println("==============================================================");

        // Print headings
        System.out.printf("%-22s", "Product");

        for (String month : monthNames) {
            System.out.printf("%-12s", month);
        }

        System.out.printf("%-12s%-12s%n", "Total", "Average");

        System.out.println("--------------------------------------------------------------");

        int companyTotalSales = 0;
        Product mostPopularProduct = products[0];

        // Print each product's sales
        for (Product product : products) {

            System.out.printf("%-22s", product.getProductName());

            for (int sales : product.getMonthlySales()) {
                System.out.printf("%-12d", sales);
            }

            int productTotal = product.calculateTotalSales();
            double productAverage = product.calculateAverageSales();

            System.out.printf("%-12d%-12.2f%n",
                    productTotal,
                    productAverage);

            companyTotalSales += productTotal;

            // Determine the most popular product
            if (productTotal > mostPopularProduct.calculateTotalSales()) {
                mostPopularProduct = product;
            }
        }

        double averageSalesPerProduct =
                (double) companyTotalSales / products.length;

        System.out.println("==============================================================");
        System.out.println("SALES SUMMARY");
        System.out.println("==============================================================");

        System.out.println("Total number of products sold: "
                + companyTotalSales);

        System.out.printf("Average number sold per product: %.2f%n",
                averageSalesPerProduct);

        System.out.println("Most popular product: "
                + mostPopularProduct.getProductName());

        System.out.println("Highest product sales: "
                + mostPopularProduct.calculateTotalSales());

        System.out.println("==============================================================");

        printTopThreeProducts(products);
    }

    // Print the three top-performing mattress products
    private void printTopThreeProducts(Product[] products) {

        // Copy the products into another array
        Product[] sortedProducts = new Product[products.length];

        for (int i = 0; i < products.length; i++) {
            sortedProducts[i] = products[i];
        }

        // Bubble sort products from highest to lowest sales
        for (int i = 0; i < sortedProducts.length - 1; i++) {

            for (int j = 0; j < sortedProducts.length - i - 1; j++) {

                if (sortedProducts[j].calculateTotalSales()
                        < sortedProducts[j + 1].calculateTotalSales()) {

                    Product temporaryProduct = sortedProducts[j];
                    sortedProducts[j] = sortedProducts[j + 1];
                    sortedProducts[j + 1] = temporaryProduct;
                }
            }
        }

        System.out.println();
        System.out.println("==============================================================");
        System.out.println("               TOP THREE PERFORMING PRODUCTS");
        System.out.println("==============================================================");

        int numberOfTopProducts = Math.min(3, sortedProducts.length);

        for (int i = 0; i < numberOfTopProducts; i++) {

            System.out.println((i + 1) + ". "
                    + sortedProducts[i].getProductName()
                    + " - "
                    + sortedProducts[i].calculateTotalSales()
                    + " units");
        }

        System.out.println("==============================================================");
    }
}


// Main application class

public class MattressSales {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Single-dimensional array storing the month names
        String[] monthNames = {
            "January",
            "February",
            "March"
        };

        // Single-dimensional array storing the product names
        String[] productNames = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
            
        };

        /*
         * Two-dimensional array storing product sales.
         *
         * Rows represent products.
         * Columns represent January, February and March.
         */
        int[][] productSales = new int[productNames.length][monthNames.length];

        System.out.println("=================================================");
        System.out.println("      MATTRESS SALES REPORT");
        System.out.println("=================================================");

        // Capture sales for every product over three months
        for (int product = 0;
             product < productNames.length;
             product++) {

            System.out.println();
            System.out.println("Enter sales for "
                    + productNames[product] + ":");

            for (int month = 0;
                 month < monthNames.length;
                 month++) {

                productSales[product][month] =
                        getValidSalesInput(
                                scanner,
                                monthNames[month]
                        );
            }
        }

        // Create an array of Product objects
        Product[] products = new Product[productNames.length];

        for (int i = 0; i < productNames.length; i++) {

            products[i] = new Product(
                    productNames[i],
                    productSales[i]
            );
        }

        // Create the report printer and display the report
        PrintProduct printProduct =
                new PrintProduct(monthNames);

        printProduct.printSalesReport(products);

        scanner.close();
    }

    // Method that prevents invalid or negative sales values
    private static int getValidSalesInput(
            Scanner scanner,
            String monthName) {

        while (true) {

            System.out.print(monthName + ": ");

            if (scanner.hasNextInt()) {

                int sales = scanner.nextInt();

                if (sales >= 0) {
                    return sales;
                }

                System.out.println(
                        "Sales cannot be negative. Please try again."
                );

            } else {

                System.out.println(
                        "Invalid input. Please enter a whole number."
                );

                scanner.next();
            }
        }
    }
}