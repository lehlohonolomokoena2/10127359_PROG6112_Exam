/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matresssalesreport;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

/**
 *
 * @author Lehlohonolo.Mokoena
 */
public class MatressSalesReport extends JFrame implements ActionListener {
    
    // GUI Components
    private JTextField txtCustomerName;
    private JComboBox<String> cmbProductName;
    private JTextField txtSalesPrice;

    private JTextField txtVAT;
    private JTextField txtCommission;
    private JTextField txtTotal;

    private JButton btnCalculate;
    private JButton btnClear;
    private JButton btnExit;

    // VAT = 15% and Commission = 5%
    private static final double VAT_RATE = 0.15;
    private static final double COMMISSION_RATE = 0.05;

    private final DecimalFormat money =
            new DecimalFormat("R #,##0.00");

    // Constructor
    public MatressSalesReport() {

        setTitle("Mattress Sales Application");
        setSize(550, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 15));
        mainPanel.setBorder(new EmptyBorder(20, 30, 20, 30));

        // ============================================
        // HEADING
        // ============================================

        JLabel lblHeading =
                new JLabel("MATTRESS SALES APPLICATION",
                        SwingConstants.CENTER);

        lblHeading.setFont(
                new Font("Arial", Font.BOLD, 22)
        );

        lblHeading.setForeground(
                new Color(0, 70, 140)
        );

        mainPanel.add(lblHeading, BorderLayout.NORTH);

        // ============================================
        // FORM PANEL
        // ============================================

        JPanel formPanel =
                new JPanel(new GridLayout(6, 2, 10, 15));

        // Customer Name
        JLabel lblCustomerName =
                new JLabel("Customer Name:");

        txtCustomerName = new JTextField();

        // Product Name
        JLabel lblProductName =
                new JLabel("Product Name:");

        // Combo box containing mattress products
        String[] products = {
                "Cozy Nights",
                "Monarch"
        };

        cmbProductName =
                new JComboBox<>(products);

        // Sales Price
        JLabel lblSalesPrice =
                new JLabel("Sales Price:");

        txtSalesPrice =
                new JTextField();

        // VAT
        JLabel lblVAT =
                new JLabel("VAT Amount (15%):");

        txtVAT =
                new JTextField();

        txtVAT.setEditable(false);

        // Commission
        JLabel lblCommission =
                new JLabel("Commission (5%):");

        txtCommission =
                new JTextField();

        txtCommission.setEditable(false);

        // Total Amount
        JLabel lblTotal =
                new JLabel("Total Sales Amount:");

        txtTotal =
                new JTextField();

        txtTotal.setEditable(false);

        // Add components to form
        formPanel.add(lblCustomerName);
        formPanel.add(txtCustomerName);

        formPanel.add(lblProductName);
        formPanel.add(cmbProductName);

        formPanel.add(lblSalesPrice);
        formPanel.add(txtSalesPrice);

        formPanel.add(lblVAT);
        formPanel.add(txtVAT);

        formPanel.add(lblCommission);
        formPanel.add(txtCommission);

        formPanel.add(lblTotal);
        formPanel.add(txtTotal);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // ============================================
        // BUTTON PANEL
        // ============================================

        JPanel buttonPanel = new JPanel();

        btnCalculate =
                new JButton("Calculate");

        btnClear =
                new JButton("Clear");

        btnExit =
                new JButton("Exit");

        // Add action listeners
        btnCalculate.addActionListener(this);
        btnClear.addActionListener(this);
        btnExit.addActionListener(this);

        buttonPanel.add(btnCalculate);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnExit);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);

        setVisible(true);
    }

    // ============================================
    // BUTTON EVENTS
    // ============================================

    @Override
    public void actionPerformed(ActionEvent event) {

        if (event.getSource() == btnCalculate) {

            calculateSale();

        } else if (event.getSource() == btnClear) {

            clearForm();

        } else if (event.getSource() == btnExit) {

            System.exit(0);
        }
    }

    // ============================================
    // CALCULATE METHOD
    // ============================================

    private void calculateSale() {

        String customerName =
                txtCustomerName.getText().trim();

        String productName =
                cmbProductName.getSelectedItem().toString();

        // Validate customer name
        if (customerName.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the customer's name.",
                    "Customer Name Required",
                    JOptionPane.WARNING_MESSAGE
            );

            txtCustomerName.requestFocus();
            return;
        }

        // Validate sales price
        if (txtSalesPrice.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the mattress sales price.",
                    "Sales Price Required",
                    JOptionPane.WARNING_MESSAGE
            );

            txtSalesPrice.requestFocus();
            return;
        }

        try {

            // Get sales price from text field
            double salesPrice =
                    Double.parseDouble(
                            txtSalesPrice.getText().trim()
                    );

            if (salesPrice <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Sales price must be greater than zero.",
                        "Invalid Price",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            // ============================================
            // CALCULATIONS
            // ============================================

            // VAT = Sales price x 15%
            double vatAmount =
                    salesPrice * VAT_RATE;

            // Commission = Sales price x 5%
            double commission =
                    salesPrice * COMMISSION_RATE;

            // Total = Price + VAT + Commission
            double totalAmount =
                    salesPrice
                    + vatAmount
                    + commission;

            // ============================================
            // DISPLAY RESULTS
            // ============================================

            txtVAT.setText(
                    money.format(vatAmount)
            );

            txtCommission.setText(
                    money.format(commission)
            );

            txtTotal.setText(
                    money.format(totalAmount)
            );

            // Display transaction summary
            JOptionPane.showMessageDialog(
                    this,

                    "MATRESS SALES REPORT\n\n"
                    + "Customer Name: "
                    + customerName
                    + "\n"
                    + "Product Name: "
                    + productName
                    + "\n"
                    + "Sales Price: "
                    + money.format(salesPrice)
                    + "\n"
                    + "VAT (15%): "
                    + money.format(vatAmount)
                    + "\n"
                    + "Commission (5%): "
                    + money.format(commission)
                    + "\n"
                    + "Total Sales Amount: "
                    + money.format(totalAmount),

                    "Sales Report",

                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid numerical sales price.\n"
                    + "For example: 5000 or 5999.99",
                    "Invalid Sales Price",
                    JOptionPane.ERROR_MESSAGE
            );

            txtSalesPrice.requestFocus();
        }
    }

    // ============================================
    // CLEAR METHOD
    // ============================================

    private void clearForm() {

        txtCustomerName.setText("");

        cmbProductName.setSelectedIndex(0);

        txtSalesPrice.setText("");

        txtVAT.setText("");

        txtCommission.setText("");

        txtTotal.setText("");

        txtCustomerName.requestFocus();
    }





    public static void main(String[] args) {
                SwingUtilities.invokeLater(() -> {

            new MatressSalesReport();

        }
   }
    
